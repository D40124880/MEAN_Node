var math_me = require('./mathlib')();

math_me.add(2, 3);
math_me.multiply(4, 5);
math_me.square(10);
math_me.random(8, 4);
math_me.random(8, 4);
math_me.random(8, 4);
math_me.random(8, 4);
math_me.random(8, 4);